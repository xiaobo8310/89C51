#ifndef _public_H
#define	_public_H

#include "reg52.h"

typedef unsigned char u8;
typedef unsigned int u16;

void delay(u16 i);



#endif
